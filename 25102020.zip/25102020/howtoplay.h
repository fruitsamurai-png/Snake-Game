#pragma once

void howtoplay_init(void);
void howtoplay_update(void);
void howtoplay_exit(void);
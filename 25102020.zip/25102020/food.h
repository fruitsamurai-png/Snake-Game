#pragma once

struct food
{
	int x, y, foodcount;
}food;

void Food_init(void);
void Food_update(void);
void Food_exit(void);
#include "cprocessing.h"
#include "food.h"
#include "main.h"

void Food_init(void)
{
	food.foodcount = 0; //spawn at the middle of the screen
		food.x = 200;
		food.y = 200;
		CP_Settings_Fill(CP_Color_Create(0, 139, 139, 255));
		CP_Graphics_DrawRect((float)food.x, (float)food.y, 30, 30);
}

void Food_update(void)
{
	if (snake.x == food.x && snake.y == food.y)//collision for the food and the snake
	{
		do {
			food.x = CP_Random_RangeInt(1, 9) * 40;//so that the food will spawn in the coordinates of multiples 40
			food.y = CP_Random_RangeInt(1, 9) * 40;
		} while (food.x == snake.x || food.y == snake.y);
		food.foodcount++;// to be implemented in the score
		snake.length++;//for increasing the snakelength when food is consumed
	}
	CP_Settings_Fill(CP_Color_Create(0, 139, 139, 255));//dark green
	CP_Graphics_DrawRect((float)food.x, (float)food.y, 30, 30);
}

void Food_exit(void)
{
}
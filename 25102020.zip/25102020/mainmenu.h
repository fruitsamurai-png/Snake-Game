#pragma once
void mainmenu_init(void);
void mainmenu_update(void);
void mainmenu_exit(void);

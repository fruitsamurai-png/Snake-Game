#pragma once

void gameover_init(void);
void gameover_update(void);
void gameover_exit(void);
